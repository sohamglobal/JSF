package mybeans;
import java.sql.*;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;

@ManagedBean (name="productInfoGenerator")
public class ProductInfoGenerator 
{
	ArrayList<Products> list;

	public ProductInfoGenerator()
	{
		list=new ArrayList<Products>();
		Products pro;
		Connection con;
		Statement st;
		ResultSet rs;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/visadb7?user=root&password=volkswagen&useSSL=false");
			st=con.createStatement();
			
			rs=st.executeQuery("select * from products;");
			while(rs.next())
			{
				pro=new Products();
				pro.setProdid(rs.getString("prodid"));
				pro.setProdnm(rs.getString("prodnm"));
				pro.setCompany(rs.getString("company"));
				pro.setPrice(rs.getDouble("price"));
				list.add(pro);
			}
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	public ArrayList<Products> getList() {
		return list;
	}

	public void setList(ArrayList<Products> list) {
		this.list = list;
	}
	
	
}
